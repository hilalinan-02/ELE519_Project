#include <avr/io.h>
#include <util/delay.h>
#include "led_i2c.h"   // LCD and I2C library
#include "DHT.h"       // DHT11 sensor library
#include <stdio.h>

#define MAX_RETRIES 3

int main(void) {
	// Initialize LCD
	lcd_initializer myLCD = {
		.device.slave_address = 0x27,  // I2C address of the LCD
		.device.baud_rate = F_100kHz,  // I2C baud rate of 100kHz
		.rows = 2,                     // 2 rows
		.columns = 16,                 // 16 columns
		.dot_size = LCD_5x8DOTS        // 5x8 dot matrix
	};
	lcd_init(myLCD);
	_delay_ms(1000);  // Wait for the LCD to initialize
	lcd_backlight();
	
	// Initialize DHT11
	Dht11 dht11 = {
		.port = 'B',
		.pin = 1
	};
	dht11_init(dht11);
	
	// Variables to hold sensor data
	uint8_t temperature = 0;
	uint8_t humidity = 0;
	uint8_t counter = 0;

	while (1) {
		// Increment the counter to verify loop runs
		counter++;

		// Retry mechanism
		uint8_t result = 1;
		for (uint8_t i = 0; i < MAX_RETRIES; i++) {
			result = dht11_read(&temperature, &humidity);
			if (result == 0) {
				break;  // Success, exit loop
			}
			_delay_ms(100);  // Small delay before retrying
		}

		// Check if the reading was successful and display data or error
		char buffer1[16];
		char buffer2[16];
		if (result == 0) {
			sprintf(buffer1, "Temp: %dC", temperature);
			sprintf(buffer2, "Hum: %d%% Cnt:%d", humidity, counter);
			} else {
			sprintf(buffer1, "DHT Error");
			sprintf(buffer2, "Cnt: %d", counter);
		}

		// Clear the LCD before writing new data
		lcd_clear();
		
		// Write the temperature and counter to the first line
		lcd_setCursor(0, 0);
		lcd_print(buffer1);
		
		// Write the humidity or error and counter to the second line
		lcd_setCursor(0, 1);
		lcd_print(buffer2);

		_delay_ms(5600);  // Wait for 3 seconds before the next update
	}
}
